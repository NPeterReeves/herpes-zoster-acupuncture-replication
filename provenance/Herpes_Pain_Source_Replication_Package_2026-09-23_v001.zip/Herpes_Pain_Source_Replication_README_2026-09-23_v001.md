# Herpes Pain Source Replication Package

Version: `2026-09-23_v001`

This package contains the reproducible strict source-replication analysis of
the 106-participant Herpes Pain randomized study. It contains aggregate results
only; it does not contain participant-level data.

## Primary result

- Control: 34/52 cured by day 7 (65.38%)
- Experimental: 47/54 cured by day 7 (87.04%)
- Risk difference: 21.65 percentage points (95% CI 5.44 to 36.73)
- Risk ratio: 1.33 (95% CI 1.07 to 1.66)
- Odds ratio: 3.55 (95% CI 1.34 to 9.45)
- Primary two-sided uncorrected Pearson chi-square: 6.891; p=0.008662

## Reproduction

The analysis script requires Python with `openpyxl`, `numpy`, and `scipy`.
Run it against the separately maintained deidentified working workbook:

```bash
python3 Herpes_Pain_Source_Replication_Analysis_2026-09-23_v001.py \
  --input-xlsx Herpes_Pain_Deidentified_Working_Data_2026-09-23_v001.xlsx \
  --output-dir reproduced_analysis
```

The workbook builder uses the QiBo/OpenAI artifact-tool runtime and converts
the machine-readable analysis outputs into the formatted review workbook.
The `Methods`, `VAS QC`, and `Reconciliation` worksheets document the locked
methods, structural-zero handling, and publication discrepancies.

## Integrity

`Herpes_Pain_Source_Replication_Run_Manifest_2026-09-23_v001.tsv` contains the
SHA-256 checksum and size of every analyzed output, script, and result workbook.
